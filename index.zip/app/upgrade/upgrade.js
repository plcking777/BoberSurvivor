class Upgrade {
    constructor(image, description, action) {
        this.image = image;
        this.description = description;
        this.action = action;
    }
}

export { Upgrade };